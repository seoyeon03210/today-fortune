import random
from datetime import datetime
from zoneinfo import ZoneInfo

import streamlit as st

st.set_page_config(
    page_title="오늘의 운세",
    page_icon="🔮",
    layout="centered",
)

# 부드러운 파스텔 테마
st.markdown("""
<style>
.stApp {
    background: linear-gradient(180deg, #fbf6ff 0%, #fff9fc 100%);
}
.main-title {
    text-align: center;
    color: #8754a1;
    font-size: 2.5rem;
    font-weight: 800;
    margin-bottom: 0.2rem;
}
.subtitle {
    text-align: center;
    color: #796783;
    margin-bottom: 1.8rem;
}
.fortune-card {
    background: rgba(255,255,255,0.92);
    border: 2px solid #e7d5f2;
    border-radius: 22px;
    padding: 28px 24px;
    text-align: center;
    box-shadow: 0 8px 28px rgba(126, 82, 150, 0.10);
    margin-top: 18px;
}
.fortune-name {
    color: #8754a1;
    font-size: 1.8rem;
    font-weight: 800;
    margin: 8px 0 18px 0;
}
.fortune-message {
    color: #46394d;
    font-size: 1.12rem;
    line-height: 1.9;
}
.small-note {
    color: #927e9d;
    text-align: center;
    font-size: 0.9rem;
    margin-top: 18px;
}
</style>
""", unsafe_allow_html=True)

FORTUNES = {
    "🌟 전체운": [
        ("태양 ☀️", "오늘은 긍정적인 에너지가 가득한 날! 자신감을 가지고 행동해 봐."),
        ("별 ⭐", "작은 희망이 좋은 결과로 이어질 수 있어. 네 가능성을 믿어 봐."),
        ("마법사 🪄", "새로운 일을 시작하기 좋은 날! 먼저 행동하면 기회가 찾아올 거야."),
        ("운명의 수레바퀴 🎡", "예상하지 못한 변화가 찾아올 수 있어. 열린 마음으로 하루를 보내 봐."),
        ("은둔자 🕯️", "혼자만의 시간을 가지면 생각이 정리될 거야. 서두르지 않아도 괜찮아."),
        ("세계 🌍", "그동안 노력한 일이 좋은 방향으로 나아갈 수 있어. 스스로를 칭찬해 줘."),
        ("힘 🦁", "어려운 일이 생겨도 차분하게 해결할 수 있는 날이야."),
        ("절제 🪽", "무리하기보다는 균형을 유지하는 게 중요해."),
    ],
    "💗 연애운": [
        ("연인 💞", "솔직한 마음이 관계를 더 따뜻하게 만들어 줄 수 있어."),
        ("컵의 에이스 🩷", "설레는 순간이나 다정한 대화가 기다리고 있을지도 몰라."),
        ("컵의 2 🥂", "상대방의 이야기를 잘 들어 주면 서로 가까워질 수 있어."),
        ("여사제 🌙", "상대의 마음을 섣불리 판단하지 말고 천천히 알아가 봐."),
        ("컵의 6 🧸", "추억이 떠오르는 날이야. 과거보다 지금의 마음에 집중해 봐."),
        ("절제 🌷", "관계에서 적당한 거리와 속도를 유지하는 게 좋아."),
        ("힘 🐱", "조급해하지 말고 자연스러운 모습을 보여 줘."),
        ("별 ✨", "작은 친절과 따뜻한 말 한마디가 기분 좋은 계기가 될 수 있어."),
    ],
    "📚 학업운": [
        ("마법사 ✍️", "집중력이 빛을 발할 수 있는 날! 어려운 문제도 차근차근 도전해 봐."),
        ("전차 🏇", "목표를 정하고 한 가지씩 끝내면 성취감을 얻을 수 있어."),
        ("펜타클의 8 📖", "꾸준한 반복이 실력을 만들어 주는 날이야."),
        ("태양 ☀️", "공부한 내용을 정리하거나 복습하기에 좋은 날이야."),
        ("정의 ⚖️", "실수한 부분을 정확히 확인하면 다음에 더 잘할 수 있어."),
        ("은둔자 📝", "조용한 환경에서 혼자 공부하면 도움이 될 수 있어."),
        ("힘 💪", "막히는 문제가 있어도 바로 포기하지 말고 다시 살펴봐."),
        ("펜타클의 에이스 🌱", "새로운 공부 습관을 시작하기 좋은 날이야."),
    ],
    "💰 금전운": [
        ("펜타클의 에이스 💎", "필요한 곳에 돈을 쓰고 작은 지출부터 점검해 봐."),
        ("펜타클의 9 🌿", "내가 가진 것의 가치를 발견해 보는 날이야."),
        ("정의 ⚖️", "구매하기 전 가격과 필요성을 한 번 더 비교해 봐."),
        ("절제 🪙", "충동적으로 결정하기보다 잠깐 생각하면 만족스러운 선택을 할 수 있어."),
        ("태양 ☀️", "소소한 즐거움에서 만족을 찾을 수 있는 날이야."),
        ("펜타클의 6 🎁", "주변 사람과 작은 것을 나누며 기쁨을 느낄 수 있어."),
        ("황제 👑", "계획을 세워 소비하면 마음이 한결 편해질 거야."),
        ("별 ⭐", "갖고 싶은 것이 있다면 예산부터 정해 보는 건 어때?"),
    ],
}

st.markdown('<div class="main-title">🔮 오늘의 운세 🔮</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">오늘 당신에게 찾아온 카드는?</div>', unsafe_allow_html=True)

try:
    today = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y년 %m월 %d일")
except Exception:
    today = datetime.now().strftime("%Y년 %m월 %d일")

st.markdown(f"<p style='text-align:center;color:#796783'>{today}</p>", unsafe_allow_html=True)

category = st.selectbox(
    "어떤 운세를 확인할까요?",
    list(FORTUNES.keys()),
)

if st.button("✨ 운세 뽑기 ✨", use_container_width=True, type="primary"):
    card, message = random.choice(FORTUNES[category])
    st.session_state["fortune_result"] = {
        "category": category,
        "card": card,
        "message": message,
        "date": today,
    }

if "fortune_result" in st.session_state:
    result = st.session_state["fortune_result"]
    st.markdown(
        f"""
        <div class="fortune-card">
            <div>오늘의 행운 카드</div>
            <div class="fortune-name">{result["card"]}</div>
            <hr style="border:0;border-top:1px solid #eadcf1;margin:18px 0;">
            <div class="fortune-message">{result["message"]}</div>
            <div class="small-note">🍀 오늘의 운세는 재미로 참고해 주세요!</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
else:
    st.info("위에서 운세 종류를 고른 뒤 버튼을 눌러 보세요!")

st.markdown(
    "<div class='small-note'>카드는 무작위로 선택되며, 실제 미래를 예측하는 서비스는 아닙니다.</div>",
    unsafe_allow_html=True,
)
