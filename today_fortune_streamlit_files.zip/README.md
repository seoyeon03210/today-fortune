# 🔮 오늘의 운세 웹앱

버튼을 누르면 전체운, 연애운, 학업운, 금전운 중 선택한 분야의 운세 카드가 무작위로 표시되는 Streamlit 앱입니다.

## GitHub와 Streamlit Community Cloud에 배포하기

1. GitHub에 로그인한 뒤 **New repository**를 눌러 새 저장소를 만듭니다.
2. 저장소에 `app.py`와 `requirements.txt` 두 파일을 업로드합니다.
3. https://share.streamlit.io/ 에 접속하고 GitHub 계정으로 로그인합니다.
4. **Create app**을 선택한 뒤 저장소, 브랜치(`main`), 메인 파일 경로(`app.py`)를 지정합니다.
5. **Deploy**를 누르면 배포가 시작됩니다. 완료되면 생성된 웹 주소를 다른 사람에게 공유할 수 있습니다.

이 앱은 API 키나 별도 비밀키가 필요하지 않습니다.
